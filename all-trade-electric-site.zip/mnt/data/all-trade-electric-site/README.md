# All Trade Electric — Static Site (No Build)

A lightweight, deploy‑ready website for All Trade Electric. Plain HTML/CSS/JS — **no build step**, so it works on GitHub Pages or Netlify out of the box.

## Quick Start
1. Replace placeholders:
   - Phone, email, license number, service area in `index.html`
   - Contact form endpoint (`action="https://formspree.io/f/yourid"`)
2. Upload these files to your repo root:
   - `index.html` (lowercase), `styles.css`, `script.js`, `404.html`, `.nojekyll`
3. Deploy:
   - **GitHub Pages**: Settings → Pages → Source: your branch **/ (root)**. Keep `.nojekyll` at repo root.
   - **Netlify**: New site from Git → Build command: *(leave empty)*, Publish directory: `/` (repo root).

## Notes
- Cache busting is done via `styles.css?v=20241013` — bump the number if you change CSS.
- Site works fully without JS (forms, nav still usable). JS adds nav toggle and year.
- Replace unsplash images with your own work photos for best results.
