// Simple JS for nav and year — site works without JS
const navToggle = document.querySelector('.nav-toggle');
const nav = document.getElementById('nav');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
}
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Optional: prevent empty form submits if Formspree ID not set
document.querySelectorAll('form').forEach(f => {
  f.addEventListener('submit', (e) => {
    if (f.action.includes('yourid')) {
      e.preventDefault();
      alert('Form endpoint not set yet. Replace "yourid" in the form action URL with your Formspree ID or use your own backend.');
    }
  });
});
